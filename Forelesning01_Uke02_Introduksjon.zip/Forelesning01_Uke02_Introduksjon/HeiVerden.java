/**
* Den første klassen man lager i Java
* HeiVerden er navnet på klassen, og java-filen må derfor også hete det samme.
*/
public class HeiVerden {
  /**
  * Javaapplikasjonens startpunkt (denne metoden blir kjørt når java-applikasjonen kjøres)
  */
  public static void main(String[] args) {
    // Printer ut teksten "Hei, verden!" til terminalen
    System.out.println("Hei, verden!");
  }

}

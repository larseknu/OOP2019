package no.hiof.larseknu.studentprosjekt;

import java.util.ArrayList;

public class Main {

  public static void main(String[] args) {
    Student albertEinstein = new Student("Albert", "Einstein", "523523");
    Student nikolaTesla = new Student("Nikola", "Tesla", "454545");

  }

}

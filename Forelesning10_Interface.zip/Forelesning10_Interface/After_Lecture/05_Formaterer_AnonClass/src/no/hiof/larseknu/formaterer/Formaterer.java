package no.hiof.larseknu.formaterer;

public interface Formaterer {
    public static final String STANDARD_TEKST = "BEAR with me!";

    String formaterTekst(String tekstSomSkalFormateres);
}

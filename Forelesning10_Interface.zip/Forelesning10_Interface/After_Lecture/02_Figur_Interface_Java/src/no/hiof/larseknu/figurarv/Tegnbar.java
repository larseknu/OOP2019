package no.hiof.larseknu.figurarv;

public interface Tegnbar {
    void tegn();
}

package no.hiof.larseknu.oblig4.controller;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Text;
import no.hiof.larseknu.oblig4.MainJavaFX;
import no.hiof.larseknu.oblig4.data.DataHandler;
import no.hiof.larseknu.oblig4.model.Film;

import java.time.LocalDate;
import java.util.Optional;

public class FilmController {
    @FXML
    private ListView<Film> filmListView;
    @FXML
    private Text tittelText;
    @FXML
    private TextField utgivelsesdatoTextField, spilletidTextField;
    @FXML
    private TextArea beskrivelseTextArea;
    @FXML
    private Button redigerButton;

    @FXML
    private void initialize() {
        filmListView.setItems(DataHandler.hentFilmData());

        redigerButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Film filmSomSkalRedigeres = filmListView.getSelectionModel().getSelectedItem();

                if (filmSomSkalRedigeres != null) {
                    boolean filmRedigert = MainJavaFX.getInstance().visRedigerFilmDialog(filmSomSkalRedigeres);

                    if (filmRedigert) {
                        filmListView.getSelectionModel().selectFirst();
                        filmListView.getSelectionModel().select(filmSomSkalRedigeres);
                        oppdaterFilmDetaljer(filmSomSkalRedigeres);
                    }
                }
                else {
                    Alert alertDialog = new Alert(Alert.AlertType.INFORMATION);
                    alertDialog.setTitle("Ingen film valgt");
                    alertDialog.setHeaderText("Vennligst velg en film");
                    alertDialog.showAndWait();
                }
            }
        });

        filmListView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<Film>() {
            @Override
            public void changed(ObservableValue<? extends Film> observableValue, Film gammelFilm, Film nyFilm) {
                oppdaterFilmDetaljer(nyFilm);
            }
        });

        filmListView.getSelectionModel().selectFirst();
    }

    private void oppdaterFilmDetaljer(Film enFilm) {
        if (enFilm != null) {
            tittelText.setText(enFilm.getTittel());
            beskrivelseTextArea.setText(enFilm.getBeskrivelse());
            utgivelsesdatoTextField.setText(enFilm.getUtgivelsesdato() != LocalDate.MIN ? enFilm.getUtgivelsesdato().toString() : "");

            spilletidTextField.setText(enFilm.getSpilletid() > 0 ? enFilm.getSpilletid() + " minutter" : "");
        }
    }

    public void nyButtonClicked(ActionEvent actionEvent) {
        Film nyFilm = new Film();

        boolean nyFilmLagetVellyket = MainJavaFX.getInstance().visRedigerFilmDialog(nyFilm);

        if (nyFilmLagetVellyket) {
            DataHandler.hentFilmData().add(nyFilm);
            filmListView.getSelectionModel().select(nyFilm);
        }
    }

    @FXML
    public void slettButtonClicked(ActionEvent actionEvent) {
        Film enFilm = filmListView.getSelectionModel().getSelectedItem();

        if (enFilm != null) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Slette film");
            alert.setHeaderText(null);
            alert.setContentText("Er du sikker på at du ønsker å slette filmen " + enFilm.getTittel() + "?");

            Optional<ButtonType> result = alert.showAndWait();
            if (result.orElse(ButtonType.OK) == ButtonType.OK){
                tomFilmInfo();
                filmListView.getSelectionModel().selectPrevious();
                DataHandler.hentFilmData().remove(enFilm);
            }
        }
    }

    private void tomFilmInfo() {
        tittelText.setText("");
        beskrivelseTextArea.setText("");
        utgivelsesdatoTextField.setText("");
        spilletidTextField.setText("");
    }
}

package no.hiof.larseknu.oblig4.controller;


import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import no.hiof.larseknu.oblig4.model.Film;

import java.time.LocalDate;

public class RedigerFilmController {
    @FXML
    private TextField tittelTextField, spilletidTextField;
    @FXML
    private TextArea beskrivelseTextArea;
    @FXML
    private Label feilmeldingLabel;
    @FXML
    private DatePicker utgivelsesdatoDatePicker;
    @FXML
    private Button okButton;

    private Stage dialogStage;
    private Film filmSomRedigeres;
    private boolean okClicked = false;

    @FXML
    private void initialize() {
        okButton.setDefaultButton(true);
    }

    public void setFilmSomSkalRedigeres(Film filmSomRedigeres) {
        this.filmSomRedigeres = filmSomRedigeres;

        if (filmSomRedigeres != null) {
            tittelTextField.setText(filmSomRedigeres.getTittel());
            beskrivelseTextArea.setText(filmSomRedigeres.getBeskrivelse());
            if (!filmSomRedigeres.getUtgivelsesdato().equals(LocalDate.MIN))
                utgivelsesdatoDatePicker.setValue(filmSomRedigeres.getUtgivelsesdato());
            spilletidTextField.setText(String.valueOf(filmSomRedigeres.getSpilletid()));
        }
    }

    @FXML
    private void okValgt() {
        if (sjekkOmInputErGyldig()) {
            filmSomRedigeres.setTittel(tittelTextField.getText());
            filmSomRedigeres.setBeskrivelse(beskrivelseTextArea.getText());
            if (utgivelsesdatoDatePicker.getValue() != null)
                filmSomRedigeres.setUtgivelsesdato(utgivelsesdatoDatePicker.getValue());
            filmSomRedigeres.setSpilletid(Integer.parseInt(spilletidTextField.getText()));

            okClicked = true;

            dialogStage = (Stage)okButton.getScene().getWindow();
            dialogStage.close();
        }
    }

    @FXML
    private void avbrytValgt() {
        dialogStage = (Stage)okButton.getScene().getWindow();
        dialogStage.close();
    }


    public boolean erOkValgt() {
        return okClicked;
    }

    private boolean sjekkOmInputErGyldig() {
        String feilmelding = "";

        if (tittelTextField.getText() == null || tittelTextField.getText().length() == 0) {
            feilmelding += "Tittel må settes!\n";
        }
        try {
            Integer.parseInt(spilletidTextField.getText());
        }
        catch (NumberFormatException exception) {
            feilmelding += "Spilletid er ikke et gyldig tall!\n";
        }

        if (feilmelding.length() == 0) {
            return true;
        }
        else {
            feilmeldingLabel.setText("Vennligs rett følgende feil:\n" + feilmelding);
            return false;
        }
    }

}


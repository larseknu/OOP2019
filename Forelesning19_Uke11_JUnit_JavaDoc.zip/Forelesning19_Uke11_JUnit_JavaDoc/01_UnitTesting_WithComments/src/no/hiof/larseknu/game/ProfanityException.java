package no.hiof.larseknu.game;

public class ProfanityException extends RuntimeException {
    public ProfanityException(String message) {
        super(message);
    }
}
